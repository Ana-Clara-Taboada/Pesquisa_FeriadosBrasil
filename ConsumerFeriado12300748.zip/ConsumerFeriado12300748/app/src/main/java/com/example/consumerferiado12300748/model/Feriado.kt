package com.example.consumerferiado12300748.model

data class Feriado (
    val date: String,
    val name: String,
    val type: String
)