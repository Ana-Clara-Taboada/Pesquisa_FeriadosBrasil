package com.example.consumerferiado12300748

import com.example.consumerferiado12300748.model.Feriado
import retrofit2.Response
import retrofit2.http.GET

interface BrasilApi {
        @GET("/api/feriados/v1/2025")
        suspend fun getFeriados(): Response<List<Feriado>>

}